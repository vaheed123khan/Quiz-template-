# Firebase Studio

This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.
Static
## Static Export

This project is configured for static HTML export. To build the static site:

1.  Install dependencies:
    ```bash
    npm install
    ```
2.  Build the static site:
    ```bash
    npm run build
    ```

The static files will be generated in the `out` directory. You can then deploy this `out` directory to any static hosting provider (like Vercel, Netlify, GitHub Pages, etc.).
